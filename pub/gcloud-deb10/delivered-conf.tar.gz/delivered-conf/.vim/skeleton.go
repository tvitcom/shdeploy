package main

import (
)

var (
)

type (
)

func init() {
}

func main() {
    println("Hello World!")
}
